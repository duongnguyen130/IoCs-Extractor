"""
Render each category's Splunk searches from its JSON template (see templates_store.py).

Default recommended search:   index=* ("ioc1" OR "ioc2" OR ...)
Alternatives start empty; add them on the Search Templates page.
"""

import re

from . import hunt_library as lib
from . import templates_store as store
from .extractor import CATEGORIES


def _q(v: str) -> str:
    return '"' + v.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _dedupe(values):
    seen, out = set(), []
    for v in values:
        v = (v or "").strip()
        if v and v.lower() not in seen:
            seen.add(v.lower())
            out.append(v)
    return out


def search_terms(key, items):
    """Values to search for a category."""
    if key == "tool":
        # search the executable names, not the product names
        terms = []
        for i in items:
            t = lib.lookup_tool(i["value"])
            terms.extend(t["processes"] + t.get("keywords", []) if t else [i["value"]])
        return _dedupe(terms)
    if key == "other":
        return _dedupe(i["extra"].get("raw") or i["value"] for i in items)
    if key == "malware":
        return _dedupe(re.sub(r"(?i)\s+ransomware$", "", i["value"]) for i in items)
    return _dedupe(i["value"] for i in items)


def render(template: str, scope: str, values) -> str:
    quoted = [_q(v) for v in values]
    return (template
            .replace("{iocs_comma}", ", ".join(quoted))
            .replace("{iocs_space}", " ".join(quoted))
            .replace("{iocs}", " OR ".join(quoted))
            .replace("{count}", str(len(values)))
            .replace("{scope}", scope))


def _render_search(s, scope, terms):
    out = {"title": s["title"], "spl": render(s["template"], scope, terms)}
    if s.get("note"):
        out["note"] = s["note"]
    return out


def build(result: dict, scope: str = "index=*"):
    """Return the category list for the UI with rendered recommended + alternative searches."""
    scope = (scope or "index=*").strip()
    configs = store.load_all()
    out = []
    for key, (label, group) in CATEGORIES.items():
        items = result["iocs"].get(key) or []
        if not items:
            continue
        cfg = configs[key]
        terms = search_terms(key, items)
        rec = _render_search(cfg["recommended"], scope, terms) if (cfg["recommended"] and terms) else None
        alts = [_render_search(a, scope, terms) for a in cfg["alternatives"]] if terms else []
        note = cfg.get("error")
        if key == "tool":
            noisy = [i["value"] for i in items if (lib.lookup_tool(i["value"]) or {}).get("noisy")]
            if noisy:
                note = ((note + " ") if note else "") + \
                    "Expect lots of benign hits for " + ", ".join(noisy) + ": they're legitimate and on most hosts."
        out.append({"key": key, "label": label, "group": group, "items": items,
                    "recommended": rec, "alternatives": alts, "note": note})
    return out
