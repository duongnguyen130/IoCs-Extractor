"""
Per-category Splunk search templates, stored as JSON files in ./searches/<category>.json

File format:
{
  "category": "ipv4",
  "recommended": { "title": "Recommended broad search", "template": "{scope} ({iocs})" },
  "alternatives": [
    { "title": "My firewall search", "template": "index=fw ({iocs})", "note": "optional" }
  ]
}

Placeholders (replaced at render time):
  {scope}        the "Search scope" box in the UI (default index=*)
  {iocs}         "ioc1" OR "ioc2" OR ...
  {iocs_comma}   "ioc1", "ioc2", ...          (for field IN (...) searches)
  {iocs_space}   "ioc1" "ioc2" ...
  {count}        number of IOC values

Set "recommended" to null to show no search for that category (CVEs default to this).
"""

import json
import os
import tempfile
from pathlib import Path

from .extractor import CATEGORIES

SEARCH_DIR = Path(__file__).resolve().parent.parent / "searches"
MAX_TEMPLATE_BYTES = 200_000
PLACEHOLDERS = ["{scope}", "{iocs}", "{iocs_comma}", "{iocs_space}", "{count}"]

DEFAULT_RECOMMENDED = {"title": "Recommended broad search", "template": "{scope} ({iocs})"}
NO_DEFAULT_SEARCH = {"cve"}


def default_config(key: str) -> dict:
    return {
        "category": key,
        "recommended": None if key in NO_DEFAULT_SEARCH else dict(DEFAULT_RECOMMENDED),
        "alternatives": [],
    }


def _path(key: str) -> Path:
    if key not in CATEGORIES:
        raise KeyError(key)
    return SEARCH_DIR / f"{key}.json"


def validate(cfg, key: str) -> dict:
    """Return a cleaned config or raise ValueError with a readable message."""
    if not isinstance(cfg, dict):
        raise ValueError("Top level must be a JSON object { ... }")

    def clean_search(s, where):
        if not isinstance(s, dict):
            raise ValueError(f"{where} must be an object with \"title\" and \"template\"")
        tpl = s.get("template")
        if not isinstance(tpl, str) or not tpl.strip():
            raise ValueError(f"{where}.template must be a non-empty string")
        title = s.get("title", "")
        if not isinstance(title, str):
            raise ValueError(f"{where}.title must be a string")
        note = s.get("note", "")
        if not isinstance(note, str):
            raise ValueError(f"{where}.note must be a string")
        out = {"title": title.strip() or "Untitled search", "template": tpl}
        if note.strip():
            out["note"] = note.strip()
        return out

    rec = cfg.get("recommended", None)
    rec = None if rec in (None, {}, "") else clean_search(rec, "recommended")

    alts = cfg.get("alternatives", [])
    if alts is None:
        alts = []
    if not isinstance(alts, list):
        raise ValueError("alternatives must be a list [ ... ]")
    alts = [clean_search(a, f"alternatives[{i}]") for i, a in enumerate(alts)]

    return {"category": key, "recommended": rec, "alternatives": alts}


def load(key: str) -> dict:
    p = _path(key)
    if not p.exists():
        return default_config(key)
    try:
        return validate(json.loads(p.read_text(encoding="utf-8")), key)
    except (ValueError, OSError):
        # a broken hand-edited file shouldn't take the app down
        cfg = default_config(key)
        cfg["error"] = f"{p.name} is invalid JSON or has a bad shape; using defaults until it's fixed."
        return cfg


def load_all() -> dict:
    return {k: load(k) for k in CATEGORIES}


def save(key: str, cfg) -> dict:
    clean = validate(cfg, key)
    data = json.dumps(clean, indent=2, ensure_ascii=False) + "\n"
    if len(data.encode("utf-8")) > MAX_TEMPLATE_BYTES:
        raise ValueError("Search file is too large")
    SEARCH_DIR.mkdir(parents=True, exist_ok=True)
    p = _path(key)
    fd, tmp = tempfile.mkstemp(dir=SEARCH_DIR, prefix=f".{key}.", suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(data)
    os.replace(tmp, p)  # atomic
    return clean


def reset(key: str) -> dict:
    return save(key, default_config(key))


def ensure_defaults():
    """Create any missing search files so they're visible / editable on disk."""
    SEARCH_DIR.mkdir(parents=True, exist_ok=True)
    for k in CATEGORIES:
        if not _path(k).exists():
            save(k, default_config(k))
