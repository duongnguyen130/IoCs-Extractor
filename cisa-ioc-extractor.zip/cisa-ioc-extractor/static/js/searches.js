/* Search Templates page: edit searches/<category>.json */
(() => {
  "use strict";

  const $ = (s) => document.querySelector(s);
  const editor = $("#editor");
  const statusEl = $("#tpl-status");
  const catList = $("#cat-list");

  const SAMPLES = {
    ipv4: ["203.0.113.10", "198.51.100.7"], ipv6: ["2001:db8::1"],
    domain: ["bad-domain.example", "c2.example.net"], url: ["http://203.0.113.10:8000/payload.exe"],
    email: ["actor@proton.me"],
    sha256: ["a0dc80a37eb7e2716c02a94adc8df9baedec192a77bde31669faed228d9ff526"],
    sha1: ["07353237350c35d6dc2c8f143b649cd07c71f62b"], md5: ["37c1e6931a14601bb136df5985beb0a1"],
    sha512: ["(sha512)"], ssdeep: ["384:px+JDZS7LRJyibXRmymaahSmCS8HVcS8C6YK6P+H+0Np0FO:pxeiJK4HDKZ32O"],
    filename: ["RunFileCopy.cmd", "main.exe"], commandline: ["cmd.exe /c vssadmin delete shadows"],
    registry: ["HKLM\\Software\\Example"], mutex: ["Global\\ExampleMutex"],
    tool: ["AnyDesk.exe", "rclone.exe"], malware: ["SafePay"], actor: ["Medusa Ransomware Group"],
    cve: ["CVE-2024-40766", "CVE-2023-27532"], technique: ["T1486", "T1490"], other: ["example"],
  };

  const state = { cats: [], key: null, saved: {}, defaults: {}, drafts: {} };

  // ------------------------------------------------------------- helpers
  function el(tag, attrs = {}, ...children) {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === null || v === undefined || v === false) continue;
      if (k === "class") n.className = v;
      else if (k === "text") n.textContent = v;
      else if (k === "dataset") Object.assign(n.dataset, v);
      else n.setAttribute(k, v === true ? "" : v);
    }
    for (const c of children.flat()) {
      if (c === null || c === undefined || c === false) continue;
      n.append(c instanceof Node ? c : document.createTextNode(String(c)));
    }
    return n;
  }
  let toastTimer;
  function toast(msg) {
    const t = $("#toast");
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove("show"), 1800);
  }
  function setStatus(msg, kind = "") {
    statusEl.textContent = msg;
    statusEl.className = "status" + (kind ? " " + kind : "");
  }
  const pretty = (o) => JSON.stringify(o, null, 2);
  const q = (v) => '"' + v.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';

  function render(template, scope, values) {
    const quoted = values.map(q);
    return template
      .split("{iocs_comma}").join(quoted.join(", "))
      .split("{iocs_space}").join(quoted.join(" "))
      .split("{iocs}").join(quoted.join(" OR "))
      .split("{count}").join(String(values.length))
      .split("{scope}").join(scope);
  }

  async function api(method, url, body) {
    const res = await fetch(url, {
      method,
      headers: body !== undefined ? { "Content-Type": "application/json" } : {},
      body: body !== undefined ? body : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || res.statusText);
    return data;
  }

  function notifyMainPage() {
    try { localStorage.setItem("ioc-templates-updated", String(Date.now())); } catch (_) { /* ignore */ }
  }

  // ------------------------------------------------------------- parsing / preview
  function parseEditor() {
    try {
      const obj = JSON.parse(editor.value);
      if (!obj || typeof obj !== "object" || Array.isArray(obj)) return { error: "Top level must be a JSON object { ... }" };
      const check = (s, where) => {
        if (!s || typeof s !== "object") return `${where} must be an object with "title" and "template"`;
        if (typeof s.template !== "string" || !s.template.trim()) return `${where}.template must be a non-empty string`;
        if (s.title !== undefined && typeof s.title !== "string") return `${where}.title must be a string`;
        return null;
      };
      if (obj.recommended !== null && obj.recommended !== undefined) {
        const e = check(obj.recommended, "recommended");
        if (e) return { error: e };
      }
      const alts = obj.alternatives ?? [];
      if (!Array.isArray(alts)) return { error: "alternatives must be a list [ ... ]" };
      for (let i = 0; i < alts.length; i++) {
        const e = check(alts[i], `alternatives[${i}]`);
        if (e) return { error: e };
      }
      return { obj };
    } catch (e) {
      return { error: `Invalid JSON: ${e.message}` };
    }
  }

  function updatePreview() {
    const { obj, error } = parseEditor();
    editor.classList.toggle("invalid", !!error);
    const prev = $("#preview");
    if (error) {
      setStatus(error, "error");
      prev.replaceChildren(el("p", { class: "spl-empty", text: "Fix the JSON to see a preview." }));
      return;
    }
    const dirty = editor.value !== pretty(state.saved[state.key]);
    state.drafts[state.key] = dirty ? editor.value : undefined;
    setStatus(dirty ? "Unsaved changes" : "Saved", dirty ? "" : "ok");
    markDirty();

    const sample = SAMPLES[state.key] || ["example"];
    const blocks = [];
    const mk = (s) => el("div", { class: "spl" },
      el("div", { class: "spl-head" }, el("span", { class: "spl-title" }, el("strong", { text: s.title || "Untitled search" }))),
      el("pre", { text: render(s.template, "index=*", sample) }),
      s.note ? el("p", { class: "spl-note", text: s.note }) : null);
    blocks.push(el("p", { class: "preview-label", text: "Recommended" }));
    blocks.push(obj.recommended ? mk(obj.recommended) : el("p", { class: "spl-empty", text: "None (\"recommended\": null)" }));
    const alts = obj.alternatives || [];
    blocks.push(el("p", { class: "preview-label", text: `Alternatives (${alts.length})` }));
    blocks.push(...(alts.length ? alts.map(mk) : [el("p", { class: "spl-empty", text: "No alternative searches yet." })]));
    prev.replaceChildren(...blocks);
  }

  // ------------------------------------------------------------- sidebar
  function countLabel(cfg) {
    return `${cfg.recommended ? "1" : "0"} rec · ${(cfg.alternatives || []).length} alt`;
  }
  function renderNav() {
    const items = [];
    let lastGroup = null;
    state.cats.forEach((c) => {
      if (c.group !== lastGroup) {
        items.push(el("li", { class: "grp", dataset: { group: c.group }, text: c.group }));
        lastGroup = c.group;
      }
      items.push(el("li", {},
        el("a", { href: `#${c.key}`, id: `nav-${c.key}`, class: c.key === state.key ? "active" : "" },
          el("span", { class: "lbl", text: c.label }),
          el("span", { class: "cnt", text: countLabel(state.saved[c.key]) }))));
    });
    catList.replaceChildren(...items);
    markDirty();
  }
  function markDirty() {
    state.cats.forEach((c) => {
      const a = document.getElementById(`nav-${c.key}`);
      if (a) a.querySelector(".lbl").classList.toggle("dirty", state.drafts[c.key] !== undefined);
    });
  }

  // ------------------------------------------------------------- select category
  function select(key) {
    if (!state.saved[key]) key = state.cats[0].key;
    state.key = key;
    const cat = state.cats.find((c) => c.key === key);
    $("#tpl-title").textContent = cat.label;
    $("#tpl-file").textContent = `searches/${key}.json`;
    document.title = `${cat.label} · Search Templates`;
    editor.value = state.drafts[key] ?? pretty(state.saved[key]);
    document.querySelectorAll(".tpl-cat-list a").forEach((a) => a.classList.toggle("active", a.id === `nav-${key}`));
    updatePreview();
  }

  // ------------------------------------------------------------- actions
  async function save() {
    const { obj, error } = parseEditor();
    if (error) { setStatus(error, "error"); return; }
    try {
      const data = await api("POST", `/api/searches/${state.key}`, JSON.stringify(obj));
      state.saved[state.key] = data.config;
      state.drafts[state.key] = undefined;
      editor.value = pretty(data.config);
      renderNav();
      updatePreview();
      notifyMainPage();
      toast(`Saved searches/${state.key}.json`);
    } catch (e) {
      setStatus(`Save failed: ${e.message}`, "error");
    }
  }

  $("#btn-save").addEventListener("click", save);
  editor.addEventListener("input", updatePreview);
  editor.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") { e.preventDefault(); save(); }
    if (e.key === "Tab") {           // keep focus in the editor, insert 2 spaces
      e.preventDefault();
      const { selectionStart: a, selectionEnd: b } = editor;
      editor.setRangeText("  ", a, b, "end");
      updatePreview();
    }
  });

  $("#btn-format").addEventListener("click", () => {
    const { obj, error } = parseEditor();
    if (error) { setStatus(error, "error"); return; }
    editor.value = pretty(obj);
    updatePreview();
  });

  $("#btn-add-alt").addEventListener("click", () => {
    const { obj, error } = parseEditor();
    if (error) { setStatus(`Fix the JSON first: ${error}`, "error"); return; }
    obj.alternatives = Array.isArray(obj.alternatives) ? obj.alternatives : [];
    obj.alternatives.push({ title: `Alternative search ${obj.alternatives.length + 1}`, template: "{scope} ({iocs})", note: "" });
    editor.value = pretty(obj);
    updatePreview();
    // put the cursor on the new title
    const idx = editor.value.lastIndexOf('"title": "Alternative search');
    if (idx >= 0) { editor.focus(); editor.setSelectionRange(idx + 10, editor.value.indexOf('"', idx + 10)); }
  });

  $("#btn-revert").addEventListener("click", () => {
    state.drafts[state.key] = undefined;
    editor.value = pretty(state.saved[state.key]);
    updatePreview();
  });

  $("#btn-reset").addEventListener("click", async () => {
    try {
      const data = await api("POST", `/api/searches/${state.key}/reset`);
      state.saved[state.key] = data.config;
      state.drafts[state.key] = undefined;
      editor.value = pretty(data.config);
      renderNav();
      updatePreview();
      notifyMainPage();
      toast("Reset to default");
    } catch (e) {
      setStatus(`Reset failed: ${e.message}`, "error");
    }
  });

  window.addEventListener("hashchange", () => select(decodeURIComponent(location.hash.slice(1))));
  window.addEventListener("beforeunload", (e) => {
    if (Object.values(state.drafts).some((d) => d !== undefined)) { e.preventDefault(); e.returnValue = ""; }
  });

  // ------------------------------------------------------------- init
  (async () => {
    try {
      const data = await api("GET", "/api/searches");
      state.cats = data.categories;
      state.saved = data.configs;
      renderNav();
      select(decodeURIComponent(location.hash.slice(1)) || state.cats[0].key);
    } catch (e) {
      setStatus(`Could not load templates: ${e.message}`, "error");
    }
  })();
})();
