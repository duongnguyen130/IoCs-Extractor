# CISA IOC Extractor

A local web app for SOC analysts. Upload CISA advisory **STIX 2.x JSON** bundles (the `AAxx-xxxA-stix.json`
files from cisa.gov), or paste the JSON, and get:

* **Categorized, de-duplicated IOC lists.** One value per line, so you can paste straight into an Excel column
  * Network: IPv4/IPv6, domains (Tor .onion flagged), URLs, email addresses
  * Hashes: SHA-256, SHA-1, MD5, SHA-512, SSDEEP (each linked to its file name and sibling hashes)
  * Host artifacts: file names, command lines, registry keys, mutexes
  * Tools & software (AnyDesk, Rclone, PsExec, ScreenConnect…) mapped to real **process names**
  * Malware / ransomware families and threat actors
  * **CVEs** with affected product plus NVD / CISA KEV links
  * **MITRE ATT&CK techniques**
* **A broad Splunk search for every category except CVEs**, collapsed until you expand it:
  `index=* ("ioc1" OR "ioc2" ...)`, with a nested **Alternative searches** dropdown (empty by default)
* A **Search Templates** page (`/searches`) for editing each category's searches as JSON
* **Copy all as Excel table**, **CSV download**, and a **Splunk searches .txt** download

Shared-infrastructure IPs (GitHub, Cloudflare, Google) are flagged so you know to expect benign hits.

## Requirements

Python 3.8+. **Standard library only, nothing to install.**

## Run

```bash
cd cisa-ioc-extractor
python app.py                  # → http://127.0.0.1:8080
python app.py --port 9000
python app.py --host 0.0.0.0   # share on your LAN (no auth, use with care)
```

Open the URL and drag in one or more STIX files. You can also paste the JSON: use the **Or paste JSON / IOC text** box (it validates the JSON and has a Format button), or press **Ctrl+V anywhere on the page**. Results appear automatically. Change the **search scope**
(e.g. `(index=firewall OR index=proxy OR index=edr)`) and every search regenerates. Set the time range in the
Splunk time picker.

## Project layout

```
cisa-ioc-extractor/
├── app.py                 # HTTP server + routing (/, /searches, /static/*, /api/...)
├── searches/              # one JSON search-template file per category (edit here or in the UI)
├── ioc/
│   ├── extractor.py       # STIX pattern parser, regex fallback, categorization, de-dup
│   ├── splunk.py          # renders each category's searches from its template
│   ├── templates_store.py # load / validate / save searches/*.json
│   └── hunt_library.py    # tool→process map, CVE product context, CDN ranges
├── templates/
│   ├── index.html
│   └── searches.html      # Search Templates editor
└── static/
    ├── css/style.css, searches.css
    └── js/app.js, searches.js
```

## Splunk searches

By default each category's recommended search has no pipes or time modifiers:

```
index=* ("ioc1" OR "ioc2" OR "ioc3")
```

### Editing searches

Click **Search templates** (top right) or **Edit searches (JSON)** inside any category's Splunk dropdown.
Each category is one file, `searches/<category>.json`:

```json
{
  "category": "ipv4",
  "recommended": { "title": "Recommended broad search", "template": "{scope} ({iocs})" },
  "alternatives": [
    { "title": "Firewall only", "template": "index=fw dest_ip IN ({iocs_comma})", "note": "Palo Alto logs" }
  ]
}
```

| Placeholder    | Becomes                                              |
|----------------|------------------------------------------------------|
| `{scope}`      | the Search scope box on the main page (`index=*`)    |
| `{iocs}`       | `"ioc1" OR "ioc2" OR ...`                            |
| `{iocs_comma}` | `"ioc1", "ioc2", ...` (for `field IN (...)`)         |
| `{iocs_space}` | `"ioc1" "ioc2" ...`                                  |
| `{count}`      | number of IOC values                                 |

* `"recommended": null` shows no recommended search (CVEs default to this).
* The editor checks the JSON, shows a live preview with sample IOCs, and has **+ Add alternative**,
  **Format**, **Revert**, **Reset to default** and **Save** (Ctrl+S).
* Saving updates an open extractor tab automatically. You can also edit the files by hand; they're
  re-read on every extraction.
* Back up the `searches/` folder to keep your templates.

* Every category gets a search except CVEs. That includes SSDEEP hashes and ATT&CK IDs, which only hit if
  your EDR/AV/IDS logs them as text.
* Tools are searched by executable name (e.g. `AnyDesk.exe`, `rclone.exe`). PowerShell, 7-Zip, WinRAR and
  WinRM are included but flagged as noisy.

## Extending

* **New tool → process mapping:** add an entry to `TOOLS` in `ioc/hunt_library.py`.
* **New CVE product context:** add to `CVES`.

## Notes

* Plain `.txt` / `.csv` uploads are parsed with regex (defanged `hxxp` / `[.]` are refanged).
* Uploads are processed in memory and never written to disk (only `searches/*.json` is written).
* With `--host 0.0.0.0`, anyone on the network can edit the search templates.
* Copy / CSV export prefixes values that start with `= + - @` to block Excel formula injection.
